package PracticeProject9;

public class ArrayExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = new int[3]; //declaration and instantiation
		a[0]=10;
		a[1]=20;
		a[2]=30;
		for(int i=0; i <a.length; i++) {
			System.out.println("the array is :"+a[i]);
		}

	}

}
